import React, { useEffect, useState } from "react";
import { Outlet, useLocation, Link } from "react-router-dom";
import { Menu, X, MessagesSquare, Phone, Users, FileText, Settings, UserCheck } from "lucide-react";
import "./Dashboard.css";
import "./Sidebar.css";

export default function DashboardLayout() {
  const [open, setOpen] = useState(true);
  const [mobileRail, setMobileRail] = useState(false);
  const loc = useLocation();

  // close mobile rail on route changes
  useEffect(() => { setMobileRail(false); }, [loc.pathname]);

  return (
    <div className="page-root">
      {/* soft purple haze */}
      <div className="brand-haze" />
      <div className="brand-haze delay" />

      {/* Desktop rail */}
      <aside className={`nav-rail ${open ? "open" : ""}`}>
        <div className="rail-head">
          <span className="brand">Advocate AI</span>
          <button className="rail-toggle" onClick={() => setOpen(v => !v)} aria-label="Toggle sidebar">
            {open ? <X size={18}/> : <Menu size={18}/>}
          </button>
        </div>

        <nav className="rail-nav">
          <RailLink to="/dashboard/lawyers" icon={<Users size={20} />} label="Lawyers"/>
          <RailLink to="/dashboard/assigned" icon={<UserCheck size={20} />} label="Assigned"/>
          <RailLink to="/dashboard/chat" icon={<MessagesSquare size={20} />} label="Messages"/>
          <RailLink to="/dashboard/call" icon={<Phone size={20} />} label="Calls"/>
          <RailLink to="/dashboard/docs" icon={<FileText size={20} />} label="Documents"/>
          <RailLink to="/dashboard/settings" icon={<Settings size={20} />} label="Settings"/>
        </nav>
      </aside>

      {/* Mobile top bar + slide-in panel */}
      <div className="mobile-topbar">
        <button className="ghost icon" onClick={() => setMobileRail(true)} aria-label="Open menu"><Menu/></button>
        <span className="mtitle">Advocate AI</span>
        <span className="ghost icon" />
      </div>
      <div className={`mobile-panel ${mobileRail ? "show" : ""}`} onClick={() => setMobileRail(false)}>
        <div className="mobile-panel-sheet" onClick={e => e.stopPropagation()}>
          <div className="sheet-head">
            <span className="brand">Menu</span>
            <button className="ghost icon" onClick={() => setMobileRail(false)} aria-label="Close"><X/></button>
          </div>
          <nav className="mp-nav">
            <RailLink to="/dashboard/lawyers" label="Lawyers" />
            <RailLink to="/dashboard/assigned" label="Assigned" />
            <RailLink to="/dashboard/chat" label="Messages" />
            <RailLink to="/dashboard/call" label="Calls" />
            <RailLink to="/dashboard/docs" label="Documents" />
            <RailLink to="/dashboard/settings" label="Settings" />
          </nav>
        </div>
      </div>

      <main className="shell">
        <div className="container-xx">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

function RailLink({ to, icon, label }) {
  const active = window.location.pathname.startsWith(to);
  return (
    <Link to={to} className={`rail-link ${active ? "on" : ""}`}>
      {icon && <span className="ico">{icon}</span>}
      <span className="lab">{label}</span>
    </Link>
  );
}
