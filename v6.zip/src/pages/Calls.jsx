import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Phone, Video, PhoneIncoming, PhoneOutgoing, PhoneMissed, Search, MoreVertical
} from "lucide-react";
import { lawyers } from "../data/lawyers";

/** Call History screen (WhatsApp-like) */
export default function Calls() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [tab, setTab] = useState("all"); // all | missed | incoming | outgoing
  const [showFab, setShowFab] = useState(false);

  const rows = useMemo(() => {
    const base = (lawyers?.length ? lawyers : [
      { id: "1", name: "John Smith", city: "New Delhi", avatar: "" },
      { id: "2", name: "Emily Johnson", city: "Mumbai", avatar: "" },
    ]).map((p, i) => ({
      id: String(i + 1),
      peer: { id: p.id ?? String(i + 1), name: p.name ?? "Advocate", city: p.city ?? "—", avatar: p.image || p.avatar || "" },
      type: i % 2 ? "video" : "voice",
      dir: i % 3 === 0 ? "incoming" : "outgoing",
      missed: i % 5 === 0,                                    // sprinkle misses
      time: i % 2 ? "Today, 2:17 PM" : "Yesterday, 7:42 PM",
      duration: i % 5 === 0 ? "" : (i % 2 ? "04:28" : "11:06"),
    }));
    return base
      .filter(r => (q ? (r.peer.name.toLowerCase().includes(q.toLowerCase())) : true))
      .filter(r => tab === "missed" ? r.missed :
                   tab === "incoming" ? r.dir === "incoming" && !r.missed :
                   tab === "outgoing" ? r.dir === "outgoing" && !r.missed : true);
  }, [q, tab]);

  const startCall = (peerId, type) => {
    navigate(`/dashboard/call/active?with=${peerId}&type=${type}`);
  };

  return (
    <section className="container-xx calls-page">
      <div className="hero">
        <div className="hero-title">Calls</div>
        <div className="hero-sub">Your recent audio and video calls</div>
      </div>

      {/* search + tabs */}
      <div className="panel calls-toolbar">
        <div className="calls-search">
          <Search size={16} />
          <input
            placeholder="Search advocates"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>

        <div className="calls-tabs">
          {["all","missed","incoming","outgoing"].map(key => (
            <button
              key={key}
              className={`tab-pill ${tab === key ? "on" : ""}`}
              onClick={() => setTab(key)}
            >
              {key[0].toUpperCase()+key.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* history list */}
      <div className="list calls-list">
        {rows.map(({id, peer, type, dir, missed, time, duration}) => (
          <div key={id} className={`call-item ${missed ? "missed" : ""}`}>
            <img
              src={peer.avatar || "/assets/placeholder-avatar.png"}
              alt=""
              className="call-ava"
              onError={(e)=>{e.currentTarget.src="/assets/placeholder-avatar.png";}}
            />
            <div className="call-mid">
              <div className="call-name-row">
                <div className="call-name">{peer.name}</div>
                <span className={`badge ${type}`}>{type === "video" ? "Video" : "Voice"}</span>
              </div>
              <div className="call-meta">
                <span className={`ico ${missed ? "miss" : dir}`}>
                  {missed ? <PhoneMissed size={14}/> : (dir === "incoming" ? <PhoneIncoming size={14}/> : <PhoneOutgoing size={14}/>)}
                </span>
                <span>{time}</span>
                {duration && <span className="sep">•</span>}
                {duration && <span>{duration}</span>}
              </div>
            </div>
            <div className="call-actions">
              <button className="icon-btn ghost" title="Voice call" onClick={() => startCall(peer.id, "voice")}><Phone size={18}/></button>
              <button className="icon-btn ghost" title="Video call" onClick={() => startCall(peer.id, "video")}><Video size={18}/></button>
              <button className="icon-btn ghost" title="More"><MoreVertical size={18}/></button>
            </div>
          </div>
        ))}
        {rows.length === 0 && (
          <div className="panel subtle empty-state">
            No calls here yet.
          </div>
        )}
      </div>

      {/* FAB: calling button */}
      <div className="fab-wrap">
        <button className="fab-call" onClick={() => setShowFab(v=>!v)} aria-label="New call">
          <Phone size={20}/>
        </button>

        {showFab && (
          <div className="fab-menu" onClick={(e)=>e.stopPropagation()}>
            <button className="fab-chip" onClick={()=>startCall(lawyers?.[0]?.id || "advocate","voice")}>
              <Phone size={16}/> Voice
            </button>
            <button className="fab-chip" onClick={()=>startCall(lawyers?.[0]?.id || "advocate","video")}>
              <Video size={16}/> Video
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
