import React, { useEffect, useRef, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Mic, MicOff, Video, VideoOff, Volume2, Camera, PhoneOff, ArrowLeft } from "lucide-react";

/**
 * CallActive.jsx
 * - Shows a full-screen remote canvas, draggable PiP for local
 * - Fallback <video> is visible until the canvas has painted at least one frame
 * - Works even without signaling (uses getUserMedia for both local/remote demo)
 *   -> Replace the fakeRemoteStream section with your real remote stream
 */

export default function CallActive() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const who = params.get("with") || "John Smith";

  // Canvas + <video> refs
  const remoteCanvasRef = useRef(null);
  const remoteVideoRef = useRef(null);   // fallback video
  const localVideoRef  = useRef(null);   // PiP <video>

  const [hasFrame, setHasFrame] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [uiVisible, setUiVisible] = useState(true);

  // PiP drag state
  const pipRef = useRef(null);
  const dragState = useRef(null);

  // Helper: draw loop using rVFC if available
  const startPaintLoop = (videoEl, canvasEl) => {
    const ctx = canvasEl.getContext("2d", { alpha: false });
    let rafId = 0;
    let running = true;

    const resize = () => {
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      const { clientWidth: w, clientHeight: h } = canvasEl;
      if (canvasEl.width !== Math.floor(w * dpr) || canvasEl.height !== Math.floor(h * dpr)) {
        canvasEl.width = Math.floor(w * dpr);
        canvasEl.height = Math.floor(h * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }
    };

    const draw = () => {
      if (!running) return;
      resize();
      if (videoEl.readyState >= 2 && !videoEl.paused) {
        // cover-fit draw (center-crop)
        const vw = videoEl.videoWidth || 1;
        const vh = videoEl.videoHeight || 1;
        const cw = canvasEl.clientWidth || 1;
        const ch = canvasEl.clientHeight || 1;
        const vr = vw / vh; const cr = cw / ch;

        let sx, sy, sw, sh;
        if (vr > cr) {
          // video wider: crop sides
          sh = vh; sw = vh * cr; sx = (vw - sw) / 2; sy = 0;
        } else {
          // video taller: crop top/bottom
          sw = vw; sh = vw / cr; sx = 0; sy = (vh - sh) / 2;
        }
        ctx.drawImage(videoEl, sx, sy, sw, sh, 0, 0, cw, ch);
        setHasFrame(true); // first painted frame -> hide fallback
      }
      rafId = requestAnimationFrame(draw);
    };

    // Prefer rVFC for efficiency
    if ("requestVideoFrameCallback" in HTMLVideoElement.prototype) {
      const step = () => {
        if (!running) return;
        resize();
        try {
          ctx.drawImage(videoEl, 0, 0, canvasEl.clientWidth, canvasEl.clientHeight);
          setHasFrame(true);
        } catch {}
        videoEl.requestVideoFrameCallback(step);
      };
      videoEl.requestVideoFrameCallback(step);
      return () => { running = false; };
    }

    rafId = requestAnimationFrame(draw);
    return () => { running = false; cancelAnimationFrame(rafId); };
  };

  // Get media + demo remote stream (replace with your signaling/remote stream)
  useEffect(() => {
    let stopPaint = null;
    let localStream, remoteStream;

    (async () => {
      try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (localVideoRef.current) {
          Object.assign(localVideoRef.current, { srcObject: localStream, muted: true, playsInline: true });
          await localVideoRef.current.play().catch(() => {});
        }

        // DEMO remote stream: clone local video track to pretend remote
        // Replace this whole block with your real remote stream assignment.
        const track = localStream.getVideoTracks()[0];
        remoteStream = new MediaStream(track ? [track] : []);
        if (remoteVideoRef.current) {
          Object.assign(remoteVideoRef.current, { srcObject: remoteStream, muted: true, playsInline: true });
          await remoteVideoRef.current.play().catch(() => {});
        }

        // Paint remote <video> → canvas
        if (remoteVideoRef.current && remoteCanvasRef.current) {
          stopPaint = startPaintLoop(remoteVideoRef.current, remoteCanvasRef.current);
        }
      } catch (e) {
        console.error("Media error:", e);
      }
    })();

    // Cleanup
    return () => {
      if (stopPaint) stopPaint();
      [localStream, remoteStream].forEach(s => s && s.getTracks().forEach(t => t.stop()));
    };
  }, []);

  // Toggle UI on tap/click
  useEffect(() => {
    const handle = () => setUiVisible(v => !v);
    const stage = document.getElementById("call-stage");
    stage?.addEventListener("pointerdown", handle);
    return () => stage?.removeEventListener("pointerdown", handle);
  }, []);

  // PiP drag
  useEffect(() => {
    const el = pipRef.current;
    if (!el) return;
    const onDown = (e) => {
      const r = el.getBoundingClientRect();
      dragState.current = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      el.style.cursor = "grabbing";
    };
    const onMove = (e) => {
      if (!dragState.current) return;
      const parent = document.getElementById("call-stage")?.getBoundingClientRect();
      if (!parent) return;
      let x = e.clientX - dragState.current.dx - parent.left;
      let y = e.clientY - dragState.current.dy - parent.top;
      // keep inside
      x = Math.max(8, Math.min(x, parent.width - el.offsetWidth - 8));
      y = Math.max(8, Math.min(y, parent.height - el.offsetHeight - 8));
      el.style.left = `${x}px`; el.style.top = `${y}px`;
      el.style.right = "auto"; el.style.bottom = "auto";
    };
    const onUp = () => { dragState.current = null; el.style.cursor = "grab"; };
    el.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      el.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, []);

  // Put page into "call-mode" (hides rail, etc.)
  useEffect(() => {
    document.documentElement.classList.add("call-mode");
    return () => document.documentElement.classList.remove("call-mode");
  }, []);

  return (
    <div className="call-portal">
      <div id="call-stage" className={`call-stage-fixed ${uiVisible ? "" : "hide-ui"}`}>

        {/* Header */}
        <div className="call-topbar-fixed">
          <button className="icon-btn ghost" onClick={() => navigate(-1)} aria-label="Back">
            <ArrowLeft size={18} />
          </button>
          <div className="call-peer-meta">
            <div className="call-name">{who}</div>
            <div className="call-sub">Active call</div>
          </div>
          <div className="call-spacer" />
        </div>

        {/* Remote canvas (main) */}
        <canvas ref={remoteCanvasRef} className="call-canvas-fixed" />

        {/* Fallback remote <video> until canvas has frames */}
        <video
          ref={remoteVideoRef}
          className={`fallback-video ${hasFrame ? "hide" : ""}`}
          playsInline
          muted
        />

        {/* PiP local video (draggable) */}
        <div ref={pipRef} className="call-pip" style={{ right: 12, bottom: 120 }}>
          <video ref={localVideoRef} autoPlay playsInline muted className="fallback-video" />
        </div>

        {/* Bottom dock */}
        <div className="call-dock-fixed">
          <button className={`fab ${micOn ? "" : "is-off"}`} onClick={() => setMicOn(v => !v)} aria-label="Mic">
            {micOn ? <Mic size={18} /> : <MicOff size={18} />}
          </button>
          <button className={`fab ${camOn ? "" : "is-off"}`} onClick={() => setCamOn(v => !v)} aria-label="Video">
            {camOn ? <Video size={18} /> : <VideoOff size={18} />}
          </button>
          <button className="fab" aria-label="Speaker"><Volume2 size={18} /></button>
          <button className="fab" aria-label="Snapshot"><Camera size={18} /></button>
          <button className="fab end" aria-label="End" onClick={() => navigate(-1)}><PhoneOff size={20} /></button>
        </div>
      </div>
    </div>
  );
}
