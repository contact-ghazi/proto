import React, { useMemo, useRef, useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  ArrowLeft, Phone, Video, MoreVertical, Paperclip, Send, ShieldCheck
} from "lucide-react";

export default function Messages() {
  const { search } = useLocation();
  const navigate = useNavigate();
  const withId = new URLSearchParams(search).get("with") || "adv_priya";

  const inputRef = useRef(null);
  const fileRef = useRef(null);
  const scrollerRef = useRef(null);

  // demo peer meta (swap with your store/API as needed)
  const peer = useMemo(() => ({
    id: withId,
    name: "Adv. Priya Sharma",
    subtitle: "last seen today at 2:17 PM",
    badge: "Verified",
  }), [withId]);

  // light demo messages; wire to your socket/store later
  const [text, setText] = useState("");
  const [msgs, setMsgs] = useState([
    { id: 1, from: "them", text: "Hello, how can I assist you today?", at: "9:01 pm" },
    { id: 2, from: "me",   text: "I need help with a property dispute.", at: "9:02 pm" },
  ]);

  // auto-scroll to bottom on new messages
  useEffect(() => {
    const el = scrollerRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs.length]);

  const send = () => {
    const t = text.trim();
    if (!t) return;
    setMsgs((m) => [
      ...m,
      { id: Date.now(), from: "me", text: t, at: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }
    ]);
    setText("");
    inputRef.current?.focus();
  };

  const attachFiles = (files) => {
    if (!files || files.length === 0) return;
    const names = Array.from(files).map(f => f.name).join(", ");
    setMsgs((m) => [
      ...m,
      { id: Date.now(), from: "me", text: `📎 ${names}`, at: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }
    ]);
  };

  return (
    <section className="chat-page container-xx">
      {/* Sticky top bar */}
      <div className="chat-topbar">
        <button className="icon-btn ghost" onClick={() => navigate(-1)} aria-label="Back">
          <ArrowLeft size={18} />
        </button>

        <div className="chat-peer">
          <div className="chat-avatar">{peer.name?.[0] || "A"}</div>
          <div className="chat-peer-meta">
            <div className="chat-peer-name">
              {peer.name}
              <ShieldCheck size={14} className="vbadge" title={peer.badge} />
            </div>
            <div className="chat-peer-sub">{peer.subtitle}</div>
          </div>
        </div>

        <div className="chat-actions">
          <button className="icon-btn ghost" aria-label="Audio call" onClick={() => navigate(`/dashboard/call?with=${peer.id}`)}>
            <Phone size={18} />
          </button>
          <button className="icon-btn ghost" aria-label="Video call" onClick={() => navigate(`/dashboard/call?with=${peer.id}`)}>
            <Video size={18} />
          </button>
          <button className="icon-btn ghost" aria-label="More">
            <MoreVertical size={18} />
          </button>
        </div>
      </div>

      {/* Flexible frame: scrollable messages + sticky composer */}
      <div className="chat-frame">
        <div ref={scrollerRef} className="chat-body">
          {msgs.map(m => (
            <div key={m.id} className={`bubble ${m.from === "me" ? "me" : "them"}`}>
              <div className="bubble-text">{m.text}</div>
              <div className="bubble-meta">{m.at}</div>
            </div>
          ))}
        </div>

        <div className="chat-composer">
          <button
            className="icon-btn"
            aria-label="Add attachment"
            onClick={() => fileRef.current?.click()}
          >
            <Paperclip size={18} />
          </button>
          <input
            ref={fileRef}
            type="file"
            multiple
            hidden
            onChange={(e) => attachFiles(e.target.files)}
          />

          <input
            ref={inputRef}
            className="chat-input"
            placeholder="Type a message"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
          />

          <button className="send-btn" aria-label="Send message" onClick={send}>
            <Send size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
