import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Mic, MicOff, Volume2, VolumeX, PhoneOff, Grid, UserPlus } from "lucide-react";

/**
 * AudioCall.jsx
 * - Fullscreen audio call page
 * - Big avatar with pulsing ring + live volume bars
 * - Bottom dock: mute / speaker / keypad / add / end
 * - Hooks up local mic via getUserMedia({audio:true})
 * - Remote audio plumbing is left as a ref (remoteAudioRef) so you can connect your WebRTC
 */
export default function AudioCall() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const who = params.get("with") || "Advocate";

  const [status, setStatus] = useState("Connecting…");
  const [seconds, setSeconds] = useState(0);
  const [micOn, setMicOn] = useState(true);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [uiVisible, setUiVisible] = useState(true);

  const localStreamRef = useRef(null);
  const remoteAudioRef = useRef(null); // attach your remote audio here when you wire WebRTC
  const analyserRef = useRef(null);
  const meterRef = useRef(null);
  const hideTimer = useRef(null);

  // Add call-mode class (hide rail etc), set --vh for mobile
  useEffect(() => {
    const setVH = () => document.documentElement.style.setProperty("--vh", `${window.innerHeight * 0.01}px`);
    setVH();
    window.addEventListener("resize", setVH);
    document.documentElement.classList.add("call-mode");
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("resize", setVH);
      document.documentElement.classList.remove("call-mode");
      document.body.style.overflow = "";
    };
  }, []);

  // Mock connect -> Connected + start timer
  useEffect(() => {
    const t = setTimeout(() => setStatus("Connected"), 600);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    if (status !== "Connected") return;
    const id = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [status]);
  const fmt = (n) => `${String(Math.floor(n/60)).padStart(2,"0")}:${String(n%60).padStart(2,"0")}`;

  // Local mic + analyser for live meter
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        if (!mounted) return;
        localStreamRef.current = stream;

        // Speaker control is applied to remote audio; create an element even if not used yet
        if (remoteAudioRef.current) {
          remoteAudioRef.current.autoplay = true;
          remoteAudioRef.current.playsInline = true;
          remoteAudioRef.current.muted = !speakerOn; // default on
        }

        // Analyser
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        src.connect(analyser);
        analyserRef.current = { analyser, ctx };

        // Live bars
        const data = new Uint8Array(analyser.frequencyBinCount);
        const bars = Array.from(meterRef.current?.querySelectorAll(".ac-bar") || []);

        let raf = 0;
        const draw = () => {
          analyser.getByteTimeDomainData(data);
          // Compute a simple RMS over the first half of the buffer
          let sum = 0;
          for (let i = 0; i < data.length / 2; i++) {
            const v = (data[i] - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / (data.length / 2)); // 0..~1
          // map rms to 0..1 with a little ease
          const lvl = Math.min(1, Math.max(0, (rms - 0.02) * 6));
          bars.forEach((b, i) => {
            // staggered variation so it feels alive
            const f = lvl * (0.9 + 0.2 * Math.sin((performance.now()/300) + i));
            b.style.transform = `scaleY(${Math.max(0.12, f)})`;
            b.style.opacity = String(0.5 + 0.5 * f);
          });
          raf = requestAnimationFrame(draw);
        };
        raf = requestAnimationFrame(draw);

        return () => {
          cancelAnimationFrame(raf);
          try { ctx.close(); } catch {}
        };
      } catch (err) {
        console.error("Mic error", err);
        setStatus("Mic blocked");
      }
    })();
    return () => {
      mounted = false;
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(t => t.stop());
        localStreamRef.current = null;
      }
    };
  }, [speakerOn]);

  // Auto-hide overlays on idle
  const armHide = () => {
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setUiVisible(false), 2200);
  };
  useEffect(() => { armHide(); return () => hideTimer.current && clearTimeout(hideTimer.current); }, []);
  const revealUI = () => { setUiVisible(true); armHide(); };

  // Controls
  const toggleMic = () => {
    const tracks = localStreamRef.current?.getAudioTracks?.() || [];
    const next = !micOn;
    tracks.forEach(t => (t.enabled = next));
    setMicOn(next);
    revealUI();
  };
  const toggleSpeaker = () => {
    const next = !speakerOn;
    if (remoteAudioRef.current) remoteAudioRef.current.muted = !next;
    setSpeakerOn(next);
    revealUI();
  };
  const endCall = () => { nav(-1); };

  return (
    <section
      className={`ac-portal ${uiVisible ? "show-ui" : "hide-ui"}`}
      onPointerMove={revealUI}
      onClick={revealUI}
    >
      {/* background & haze */}
      <div className="ac-bg" />
      <div className="ac-haze" aria-hidden />

      {/* topbar */}
      <header className="ac-topbar">
        <button className="ac-icon ghost" aria-label="Back" onClick={() => nav(-1)}>
          <ArrowLeft size={18} />
        </button>
        <div className="ac-peer">
          <div className="ac-name">{who}</div>
          <div className="ac-sub">{status === "Connected" ? fmt(seconds) : status}</div>
        </div>
        <div className="ac-spacer" />
      </header>

      {/* center: avatar + pulse + meter */}
      <main className="ac-stage">
        <div className="ac-avatar-wrap">
          <div className="ac-ring" />
          <div className="ac-avatar" aria-hidden>{String(who).charAt(0).toUpperCase()}</div>
        </div>

        {/* Live volume meter (local mic) */}
        <div ref={meterRef} className="ac-meter" aria-hidden>
          {Array.from({ length: 12 }).map((_, i) => <span className="ac-bar" key={i} />)}
        </div>

        {/* Hidden audio element for remote stream (attach when ready) */}
        <audio ref={remoteAudioRef} className="ac-remote" />
      </main>

      {/* bottom dock */}
      <footer className="ac-dock" role="toolbar" aria-label="Call controls">
        <button className={`ac-fab ${micOn ? "" : "is-off"}`} onClick={toggleMic} aria-label="Mute/unmute">
          {micOn ? <Mic /> : <MicOff />}
        </button>
        <button className={`ac-fab ${speakerOn ? "" : "is-off"}`} onClick={toggleSpeaker} aria-label="Speaker">
          {speakerOn ? <Volume2 /> : <VolumeX />}
        </button>
        <button className="ac-fab" aria-label="Keypad (placeholder)">
          <Grid />
        </button>
        <button className="ac-fab" aria-label="Add participant (placeholder)">
          <UserPlus />
        </button>
        <button className="ac-fab end" onClick={endCall} aria-label="End call">
          <PhoneOff />
        </button>
      </footer>
    </section>
  );
}
